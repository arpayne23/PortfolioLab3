// Lab 3:

$(document).ready(function(){
	$("#todoList").css("background-color", "lightgray");


	const settings = {
		"async": true,
		"crossDomain": true,
		"url": "https://weatherapi-com.p.rapidapi.com/forecast.json?q=Ohio&days=7",
		"method": "GET",
		"headers": {
			"X-RapidAPI-Key": "c7e7220f4cmsh7159a7ee2c1bdd2p1cf8f3jsnbc0f866d5ffd",
			"X-RapidAPI-Host": "weatherapi-com.p.rapidapi.com"
		}
	};
	
	$.ajax(settings).done(function (response) {
		var location = response.location.name;
		$("#location").append("Current and upcoming weather in " + location + ".");
		for(var i=0; i<3; i++){
			var date = new Date(response.forecast.forecastday[i].date).toDateString();
			var condition = response.forecast.forecastday[i].day.condition.text;
			var mintemp_f = response.forecast.forecastday[i].day.mintemp_f;
			var avgtemp_f = response.forecast.forecastday[i].day.avgtemp_f;
			var maxtemp_f = response.forecast.forecastday[i].day.maxtemp_f;

			var result = "<div class='col-md-4 card'>";
			result += "<p>Date: " + date + "</p>";
			result += "<p>Condition: " + condition + "</p>";
			result += "<p>Minimum Temperature: " + mintemp_f + "&#8457; </p>";
			result += "<p>Average Temperature: " + avgtemp_f + "&#8457; </p>";
			result += "<p>Maximum Temperature: " + maxtemp_f + "&#8457; </p>";
			result +="</div>";
			$("#weatherRow").append(result);

			$("div").filter(".card").css("border", "1px solid lightgray");
			$(".card").css("padding", "1em");

		}
		
		
	});

	
	
	var items = getFromLocal('memos');
	var index;
	loadList(items);

	$('button').prop('disabled', true);
	$('input').keyup(function(){
		if($(this).val().length !== 0) {
			$('button').prop('disabled', false);
		} else {
			$('button').prop('disabled', true);
		}
	});

	$('#main-input').keypress(function(e){
		if(e.which === 13) {
			if ($('#main-input').val().length !== 0)
				$('#main-button').click();
		}
	});
	$('#main-button').click(function(){
		var value = $('#main-input').val();
		items.push(value);
		$('#main-input').val('');
		loadList(items);
		storeToLocal('memos', items);
		$('button').prop('disabled', true);
	});

	$('ul').delegate("span", "click", function(event){
		event.stopPropagation();
		index = $('span').index(this);
		$('li').eq(index).remove();
		items.splice(index, 1);
		storeToLocal('memos', items);
		
	});

	$('ul').delegate('li', 'click', function(){
		index = $('li').index(this);
		var content = items[index];
		console.log(content);
		$('#edit-input').val(content );
	});

	$('#edit-button').click(function(){
		items[index] = $('#edit-input').val();
		loadList(items);
		storeToLocal("memos", items);
	});

	function loadList(items){
		$('li').remove();
		if(items.length > 0) {
			for(var i = 0; i < items.length; i++) {
				$('ul').append('<li class= "list-group-item" data-toggle="modal" data-target="#editModal">' + items[i] + '<span class="glyphicon glyphicon-remove">Delete</span></li>');
			}
		}
	};


	function storeToLocal(key, items){
		localStorage[key] = JSON.stringify(items);
	}

	function getFromLocal(key){
		if(localStorage[key])
			return JSON.parse(localStorage[key]);
		else 
			return [];
	}

});
